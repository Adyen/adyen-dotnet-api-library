﻿namespace nexo
{
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class CardData
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public ContentInformationType ProtectedCardData;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public SensitiveCardData SensitiveCardData;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("AllowedProductCode", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string[] AllowedProductCode;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("AllowedProduct", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public AllowedProduct[] AllowedProduct;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public PaymentToken PaymentToken;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("CustomerOrder", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public CustomerOrder[] CustomerOrder;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string PaymentBrand;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string MaskedPAN;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string PaymentAccountRef;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string[] EntryMode;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string CardCountryCode;
    }
}