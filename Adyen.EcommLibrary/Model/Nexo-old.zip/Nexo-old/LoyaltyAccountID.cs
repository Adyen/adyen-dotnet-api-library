﻿namespace nexo
{
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class LoyaltyAccountID
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string[] EntryMode;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Identification;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string IdentificationSupport;

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value;
    }
}