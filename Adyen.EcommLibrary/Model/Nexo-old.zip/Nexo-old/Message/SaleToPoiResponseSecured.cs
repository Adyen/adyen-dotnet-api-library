﻿using Adyen.EcommLibrary.Security;

namespace Adyen.EcommLibrary.Model.Nexo.Message
{
    internal class SaleToPoiResponseSecured : SaleToPoiMessageSecured
    {

    }
}