﻿namespace nexo
{
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class SponsoredMerchant
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string MerchantName;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string MerchantAddress;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string MerchantCountry;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string MerchantCategoryCode;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string RegistrationID;
    }
}