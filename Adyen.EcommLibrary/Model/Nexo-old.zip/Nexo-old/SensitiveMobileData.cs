﻿namespace nexo
{
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class SensitiveMobileData
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string MSISDN;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string IMSI;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string IMEI;
    }
}