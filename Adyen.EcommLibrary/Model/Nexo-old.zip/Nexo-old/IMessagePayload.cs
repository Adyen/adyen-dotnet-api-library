﻿namespace Adyen.EcommLibrary.Model.Nexo
{
    public interface IMessagePayload { }
}
