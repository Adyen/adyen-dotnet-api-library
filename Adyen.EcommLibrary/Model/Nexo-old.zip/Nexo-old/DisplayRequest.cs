﻿namespace nexo
{
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.6.1055.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class DisplayRequest
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("DisplayOutput", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public DisplayOutput[] DisplayOutput;
    }
}